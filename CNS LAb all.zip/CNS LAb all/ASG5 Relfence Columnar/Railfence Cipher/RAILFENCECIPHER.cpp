#include <bits/stdc++.h>
using namespace std;

string Encrypt(string text, int key)
{
    string result;
    char railfence[key][text.length()];
    for (int i = 0; i < key; i++)
    {
        for (int j = 0; j < text.length(); j++)
        {
            railfence[i][j] = '\n';
        }
    }
    bool flag;
    int row = 0, col = 0;
    for (int i = 0; i < text.length(); i++)
    {
        if (row == 0)
            flag = true;
        else if (row == key - 1)
            flag = false;
        railfence[row][col++] = text[i];
        if (flag)
            row++;
        else
            row--;
    }
    for (int i = 0; i < key; i++)
    {
        for (int j = 0; j < text.length(); j++)
        {
            if (railfence[i][j] != '\n')
                result.push_back(railfence[i][j]);
        }
    }
    return result;
}

string Decrypt(string ciphertext, int key)
{
    string result;
    char railfence[key][ciphertext.length()];
    for (int i = 0; i < key; i++)
    {
        for (int j = 0; j < ciphertext.length(); j++)
        {
            railfence[i][j] = '\n';
        }
    }
    bool flag;
    int row = 0, col = 0;
    for (int i = 0; i < ciphertext.length(); i++)
    {
        if (row == 0)
            flag = true;
        else if (row == key - 1)
            flag = false;
        railfence[row][col++] = '*';
        if (flag)
            row++;
        else
            row--;
    }
    int index = 0;
    for (int i = 0; i < key; i++)
    {
        for (int j = 0; j < ciphertext.length(); j++)
        {
            if (railfence[i][j] == '*' && index < ciphertext.length())
                railfence[i][j] = ciphertext[index++];
        }
    }
    row = 0, col = 0;
    for (int i = 0; i < ciphertext.length(); i++)
    {
        if (row == 0)
            flag = true;
        else if (row == key - 1)
            flag = false;
        if (railfence[row][col] != '*')
            result.push_back(railfence[row][col++]);
        if (flag)
            row++;
        else
            row--;
    }
    return result;
}

int main()
{
    int option, key;
    string text, ciphertext;
    cout << "Enter option:\t1.Console\t2.File\n";
    cin >> option;
    cout << "Enter Depth: ";
    cin >> key;
    cin.ignore();
    switch (option)
    {
    case 1:
        cout << "Enter text: ";
        break;
    case 2:
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
        break;
    }
    getline(cin, text);
    ciphertext = Encrypt(text, key);
    cout << "Cipher Text: " << ciphertext << endl;
    cout << "Original Text: " << Decrypt(ciphertext, key);
    return 0;
}
