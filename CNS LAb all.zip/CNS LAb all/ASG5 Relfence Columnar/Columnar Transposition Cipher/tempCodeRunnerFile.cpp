#include<bits/stdc++.h>
using namespace std;

int main()
{
	std::string str = "4dXcnuJx/Bo=";
	string ans="";
	bitset<8> b;
	for (std::size_t i = 0; i < str.size(); i++) {
		// std::cout << std::bitset<8>(str[i]) << ' ';
		ans += bitset<8>(str[i]).to_string()+" ";
        // cout<<ans;
	}
	cout<<"\nString Bits: "<<ans;

	return 0;
}