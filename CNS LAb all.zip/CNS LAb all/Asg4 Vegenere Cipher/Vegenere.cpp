#include <bits/stdc++.h>
using namespace std;

string FormationOfKey(string text, string key)
{
    int i = 0;
    while (key.size() != text.size())
    {
        key.push_back(key[i]);
        i++;
    }
    return key;
}

string Encrypt(string text, string key)
{
    string cipher;
    for (int i = 0; i < text.size(); i++)
    {
        char x = (text[i] + key[i]) % 26;
        x += 'A';
        cipher.push_back(x);
    }
    return cipher;
}

string Decrypt(string ciphertext, string key)
{
    string text;
    for (int i = 0; i < ciphertext.size(); i++)
    {
        char x = (ciphertext[i] - key[i] + 26) % 26;
        x += 'A';
        text.push_back(x);
    }
    return text;
}

int main()
{
    int option;
    string key, text, ciphertext;
    cout << "Enter option:\t1.Console\t2.File\n";
    cin >> option;
    cout << "Enter key: ";
    cin >> key;
    transform(key.begin(), key.end(), key.begin(), ::toupper);
    switch (option)
    {
    case 1:
        cout << "Enter text: ";
        break;
    case 2:
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
        break;
    }
    cin >> text;
    key = FormationOfKey(text, key);
    ciphertext = Encrypt(text, key);
    cout << "Cipher Text: " << ciphertext << endl;
    cout << "Original Text: " << Decrypt(ciphertext, key);
    return 0;
}
